# BelievaBoat

## Setup

Add a `config.json` using the template from `config.example.json`.
Replace `PLACE_MAIN_TOKEN_HERE`. Additional tokens can be used for voice features. Doing so allows multiple bot users to enter different voice channels on the same server.

Run `node ./index.js`.
