module.exports = Object.freeze({
    once: 1,
    recurring: 2
});